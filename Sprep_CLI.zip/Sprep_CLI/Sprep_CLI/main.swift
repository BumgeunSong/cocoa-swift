//
//  main.swift
//  Sprep_CLI
//
//  Created by Bumgeun Song on 2021/11/29.
//

import Foundation

var sprep = DeckView()
sprep.enterDeckView()
